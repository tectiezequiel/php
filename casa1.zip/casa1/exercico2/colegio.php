<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Colegio</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Boletim do Colégio</h1>        
    </header>
    <main>

    <form name="aluno" action="resultado.php" method="get">
    <div class="q1"></class>
    <div> Informe o primeiro valor:
        <input type="text" id="nota1" name="nota1">
    </div>
    <div> Informe o segundo valor:
        <input type="text" id="nota2" name="nota2">
    </div>
    <div> Informe o terceiro valor:
        <input type="text" id="nota3" name="nota3">
    </div>
   
    <input type="submit" valor="calcular">   
    </main>
  
    <footer>
    <br>
    <a href="../home/index.html" rel="prev" target="self"> voltar</a>


    </footer>
    
</body>
</html>