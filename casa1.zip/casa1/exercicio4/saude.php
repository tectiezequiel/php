<!DOCTYPE html>
<html lang="pt_br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Saude</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <h1>IMC</h1>
    </header>
    <main>

<form name="saude" action="resultado.php" method="get">
<div class="q1">
<div> Informe seu Nome:
    <input type="text" id="saude1" name="saude1">
</div>
<div> Informe seu peso:
    <input type="text" id="saude2" name="saude2">
</div>
<div> Informe sua altura:
    <input type="text" id="saude3" name="saude3">
</div>

<input type="submit" valor="calcular">   
</main>
<footer>
<a href="../home/index.html" rel="prev" target="self"> voltar</a>
</footer>

</body>
</html>